package com.virtusa.salestracker.model;

public class Sales {

	private Integer sales;
	private Integer salesTypes;

	/**
	 * @return the salesTypes
	 */
	public Integer getSalesTypes() {
		return salesTypes;
	}

	/**
	 * @param salesTypes the salesTypes to set
	 */
	public void setSalesTypes(Integer salesTypes) {
		this.salesTypes = salesTypes;
	}

	public Integer getSales() {
		return sales;
	}

	public void setSales(Integer sales) {
		this.sales = sales;
	}
	
	
}
