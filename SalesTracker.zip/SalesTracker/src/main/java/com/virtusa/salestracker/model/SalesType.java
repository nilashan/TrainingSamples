package com.virtusa.salestracker.model;

public class SalesType {

	private String salesTypes;

	
	public String getSalesTypes() {
		return salesTypes;
	}

	
	public void setSalesTypes(String salesTypes) {
		this.salesTypes = salesTypes;
	}
}
